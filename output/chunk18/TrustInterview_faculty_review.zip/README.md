# Faculty review paper

Use `TrustInterview_IEEE_faculty.tex` as the complete, self-contained IEEE conference source. Its references and architecture diagram are included in the same file. Upload this file to Overleaf and select pdfLaTeX, or compile locally with pdfLaTeX twice.

The reviewed PDF is `../output/pdf/TrustInterview_IEEE_faculty.pdf`: seven pages including references, one figure and five tables. The exact faculty/venue page rule still needs confirmation.

For the installed workspace compiler, run `rtk proxy python paper/build_faculty_pdf.py --cached` from the workspace root. This uses the downloaded Tectonic executable and cached dependencies.

`TrustInterview_IEEE_working.tex` and `archive/` preserve development history; they are not the consolidated faculty submission.

This is a systems/architecture paper with prototype implementation and preliminary verification. It reports 69 backend tests, five interface tests, twelve analysis-tool tests and 48 offline recording cases. These are not fairness or general hallucination-accuracy measurements. Independent annotations, live-model outputs and a meaningful interview-scoring rubric remain required for efficacy claims.

The authors should review every claim, author detail and acknowledgment before submission. Original wording does not guarantee an AI-detector score or a plagiarism-check outcome.
